import { getRiskClass, getRiskLabel, getRiskColor } from './riskUtils'

const DEFAULT_WEIGHTS = {
  speech: 0.35,
  cdt: 0.35,
  oculomotor: 0.30,
}

function finiteScore(value) {
  const score = Number(value)
  return Number.isFinite(score) ? Math.min(100, Math.max(0, score)) : null
}

export function calculateMultimodalFusion(results = {}) {
  const modules = [
    { key: 'speech', label: 'Speech', score: finiteScore(results.speech?.risk_score ?? results.speech?.speechRiskScore) },
    { key: 'cdt', label: 'Clock Drawing Test', score: finiteScore(results.cdt?.cdtRiskScore ?? results.cdt?.risk_score) },
    { key: 'oculomotor', label: 'Oculomotor', score: finiteScore(results.oculomotor?.risk_score ?? results.oculomotor?.oculomotorRiskScore) },
  ]

  const available = modules.filter((module) => module.score !== null)
  const totalWeight = available.reduce((sum, module) => sum + DEFAULT_WEIGHTS[module.key], 0)
  const overallScore = totalWeight > 0
    ? available.reduce((sum, module) => sum + module.score * DEFAULT_WEIGHTS[module.key], 0) / totalWeight
    : null

  const roundedScore = overallScore === null ? null : Math.round(overallScore * 10) / 10
  const riskClass = roundedScore === null ? null : getRiskClass(roundedScore)

  return {
    modules: modules.map((module) => ({
      ...module,
      weight: DEFAULT_WEIGHTS[module.key],
      available: module.score !== null,
      contribution: module.score === null ? 0 : Math.round((module.score * DEFAULT_WEIGHTS[module.key]) * 10) / 10,
    })),
    availableCount: available.length,
    completionPercent: Math.round((available.length / modules.length) * 100),
    score: roundedScore,
    riskClass,
    riskLabel: riskClass === null ? 'Incomplete screening' : getRiskLabel(riskClass),
    riskColor: riskClass === null ? 'var(--text-muted)' : getRiskColor(riskClass),
    weights: DEFAULT_WEIGHTS,
  }
}

