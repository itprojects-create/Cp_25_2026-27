import { CheckCircle2, CircleAlert, RotateCcw } from 'lucide-react'
import { Link, useNavigate } from 'react-router-dom'

import Navbar from '../components/layout/Navbar'
import Footer from '../components/layout/Footer'
import PageHeader from '../components/ui/PageHeader'
import Button from '../components/ui/Button'
import { useApp } from '../context/AppContext'
import { calculateMultimodalFusion } from '../utils/multimodalFusion'

export default function ScreeningResultsPage() {
  const navigate = useNavigate()
  const { currentPatient, screeningResults, screeningAssessmentIds, finishScreening, startScreening } = useApp()
  const fusion = calculateMultimodalFusion(screeningResults)

  const restart = () => {
    if (currentPatient) {
      startScreening(currentPatient)
      navigate('/speech?flow=full')
    } else {
      navigate('/speech?flow=full')
    }
  }

  const complete = () => {
    finishScreening()
    navigate('/profile')
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'var(--bg-base)' }}>
      <Navbar />
      <main className="flex-1">
        <div className="container">
          <PageHeader
            label="SCREENING COMPLETE · MULTIMODAL OVERVIEW"
            title="Your screening summary"
            italicWord="summary"
            description="A transparent weighted-mean view of the completed module scores. This is a preliminary screening aid, not a diagnosis."
          />
          <div className="rounded-xl p-6 mb-6" style={{ background: 'var(--bg-dark)', color: 'var(--text-on-dark)' }}>
            <div className="label-mono" style={{ color: 'var(--text-on-dark-muted)' }}>Overall weighted risk score</div>
            <div className="flex items-end gap-3 mt-2">
              <span className="text-6xl font-medium" style={{ color: fusion.riskColor }}>{fusion.score ?? '—'}</span>
              <span className="mb-2" style={{ color: 'var(--text-on-dark-muted)' }}>/ 100</span>
            </div>
            <h2 className="text-2xl mt-2">{fusion.riskLabel}</h2>
            <p className="mt-2" style={{ color: 'var(--text-on-dark-muted)' }}>
              {fusion.availableCount === 3
                ? 'All three modalities contributed to this overview.'
                : `${fusion.availableCount} of 3 modalities contributed. Complete all modules for the full overview.`}
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-4 mb-8">
            {fusion.modules.map((module) => (
              <Link
                key={module.key}
                to={module.key === 'speech'
                  ? '/speech?review=latest'
                  : module.key === 'cdt' && screeningAssessmentIds.cdt
                    ? `/cdt/result/${screeningAssessmentIds.cdt}`
                    : module.key === 'cdt'
                      ? '/cdt'
                      : '/oculomotor?review=latest'}
                className="rounded-xl p-5 block transition-transform hover:-translate-y-1"
                style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-light)' }}
                aria-label={`Review detailed ${module.label} result`}
              >
                <div className="flex justify-between items-center">
                  <span className="font-medium">{module.label}</span>
                  {module.available ? <CheckCircle2 size={17} style={{ color: 'var(--accent-primary)' }} /> : <CircleAlert size={17} style={{ color: 'var(--text-muted)' }} />}
                </div>
                <div className="text-3xl mt-4">{module.available ? module.score : '—'}</div>
                <div className="text-sm mt-1" style={{ color: 'var(--text-muted)' }}>
                  Weight {(module.weight * 100).toFixed(0)}% · Contribution {module.available ? module.contribution : '—'}
                </div>
                <div className="mt-4 h-2 rounded-full" style={{ background: 'var(--divider)' }}>
                  <div className="h-2 rounded-full" style={{ width: `${module.score ?? 0}%`, background: 'var(--accent-primary)' }} />
                </div>
                <div className="label-mono mt-4" style={{ color: 'var(--accent-primary)' }}>Open detailed result →</div>
              </Link>
            ))}
          </div>
          <div className="rounded-xl p-6 mb-8" style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-light)' }}>
            <h2 className="text-xl">How this overview is calculated</h2>
            <p className="mt-2" style={{ color: 'var(--text-secondary)' }}>
              Overall score = Speech × 35% + CDT × 35% + Oculomotor × 30%. Missing modules are excluded and the remaining weights are renormalized. These weights are an interpretable product configuration inspired by the paper&apos;s proposed late-fusion direction; they are not clinically calibrated.
            </p>
          </div>
          <div className="flex flex-wrap gap-3 mb-16">
            <Button onClick={complete}>Finish and return to profile</Button>
            <Button variant="ghost" onClick={restart} icon={<RotateCcw size={15} />}>Run again</Button>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
