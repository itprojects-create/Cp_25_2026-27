import { useEffect, useRef, useState } from 'react'
import { AlertCircle, Camera, CheckCircle2, X } from 'lucide-react'
import { FaceMesh } from '@mediapipe/face_mesh'

import Button from '../ui/Button'

const TRIAL_COUNT = 10
const CALIBRATION_MS = 5000
const FIXATION_MS = 1500
const RESPONSE_MS = 1500
const PURSUIT_MS = 10000
const HEAD_HOLD_MS = 600
const FEEDBACK_MS = 800
const HEAD_BOX = { width: '32%', height: '42%' }
const CAMERA_FOV_DEG = 60
const SACCADE_THRESHOLD_DEG_S = 30
const HEAD_BOX_TOLERANCE = 0.03

const LANDMARKS = {
  nose: 1,
  leftOuter: 33,
  rightOuter: 263,
  leftInner: 133,
  rightInner: 362,
  leftUpper: 159,
  leftLower: 145,
  rightUpper: 386,
  rightLower: 374,
  leftIris: [468, 469, 470, 471, 472],
  rightIris: [473, 474, 475, 476, 477],
}

function median(values) {
  if (!values.length) return 0
  const sorted = [...values].sort((a, b) => a - b)
  return sorted[Math.floor(sorted.length / 2)]
}

function gazeFromLandmarks(landmarks) {
  const eye = (irisIndices, inner, outer, upper, lower) => {
    const irisX = median(irisIndices.map((index) => landmarks[index].x))
    const irisY = median(irisIndices.map((index) => landmarks[index].y))
    const width = Math.abs(landmarks[outer].x - landmarks[inner].x)
    const height = Math.abs(landmarks[lower].y - landmarks[upper].y)
    if (width < 0.01 || height < 0.005) return null
    return {
      x: ((irisX - landmarks[inner].x) / width) - 0.5,
      y: ((irisY - landmarks[upper].y) / height) - 0.5,
    }

  }

  const left = eye(LANDMARKS.leftIris, LANDMARKS.leftInner, LANDMARKS.leftOuter, LANDMARKS.leftUpper, LANDMARKS.leftLower)
  const right = eye(LANDMARKS.rightIris, LANDMARKS.rightInner, LANDMARKS.rightOuter, LANDMARKS.rightUpper, LANDMARKS.rightLower)
  const samples = [left, right].filter(Boolean)
  if (!samples.length) return null

  return {
    x: samples.reduce((sum, sample) => sum + sample.x, 0) / samples.length,
    y: samples.reduce((sum, sample) => sum + sample.y, 0) / samples.length,
  }
}

function classifySaccade(samples, stimulusSide) {
  for (let index = 1; index < samples.length; index += 1) {
    const previous = samples[index - 1]
    const current = samples[index]
    const elapsedSeconds = (current.time - previous.time) / 1000
    if (elapsedSeconds <= 0) continue

    const velocity = Math.abs(current.x - previous.x) * (CAMERA_FOV_DEG / 2) / elapsedSeconds
    if (velocity <= SACCADE_THRESHOLD_DEG_S) continue

    // The preview is mirrored for the participant, so the raw landmark
    // direction is opposite to the participant's perceived left/right.
    const direction = current.x > previous.x ? 'left' : 'right'
    const correctSide = stimulusSide === 'left' ? 'right' : 'left'
    return {
      direction,
      error: direction === stimulusSide,
      latency: direction === correctSide ? current.time - samples[0].time : RESPONSE_MS,
    }
  }

  return {
    direction: 'none',
    error: true,
    latency: RESPONSE_MS,
  }
}

export default function OculomotorTestPanel({ onComplete, onCancel }) {
  const videoRef = useRef(null)
  const streamRef = useRef(null)
  const meshRef = useRef(null)
  const rafRef = useRef(0)
  const phaseRef = useRef('requesting')
  const deadlineRef = useRef(0)
  const baselineRef = useRef({ x: 0, y: 0 })
  const calibrationRef = useRef({ x: [], y: [], headX: [], headY: [] })
  const currentGazeRef = useRef(null)
  const previousGazeRef = useRef(null)
  const trialRef = useRef(0)
  const sideRef = useRef('left')
  const trialResultsRef = useRef([])
  const responseRef = useRef(null)
  const stimulusSamplesRef = useRef([])
  const fixationSamplesRef = useRef([])
  const holdStartedRef = useRef(null)
  const pursuitRef = useRef([])
  const pursuitPreviousRef = useRef(null)
  const headInsideRef = useRef(false)
  const faceDetectedRef = useRef(false)
  const trackingBusyRef = useRef(false)
  const [phase, setPhase] = useState('requesting')
  const [countdown, setCountdown] = useState(5)
  const [trial, setTrial] = useState(0)
  const [stimulusSide, setStimulusSide] = useState('left')
  const [dotX, setDotX] = useState(50)
  const [headInside, setHeadInside] = useState(false)
  const [faceDetected, setFaceDetected] = useState(false)
  const [error, setError] = useState(null)
  const [faceBox, setFaceBox] = useState(null)

  function changePhase(nextPhase) {
    phaseRef.current = nextPhase
    setPhase(nextPhase)
  }

  function finishTest() {
    const trials = trialResultsRef.current
    const pursuit = pursuitRef.current
    const calibrationSamples = calibrationRef.current.x.length
    const validTrialCount = trials.filter((item) => item.sampleCount >= 5).length
    if (calibrationSamples < 30 || validTrialCount < Math.ceil(TRIAL_COUNT * 0.8) || pursuit.length < 20) {
      setError('Tracking quality was too low to calculate a reliable result. Keep your face inside the box, improve lighting, and repeat the test.')
      changePhase('quality-error')
      return
    }
    const gains = pursuit.length > 10
      ? pursuit.map((sample) => sample.targetVelocity === 0 ? 0 : sample.gazeVelocity / sample.targetVelocity).filter(Number.isFinite)
      : []
    onComplete({
      trial_count: TRIAL_COUNT,
      antisaccade_errors: trials.filter((item) => item.error).length,
      avg_latency_ms: Math.round(trials.length ? trials.reduce((sum, item) => sum + item.latency, 0) / trials.length : 0),
      fixation_rmsd: trials.length ? Math.sqrt(trials.reduce((sum, item) => sum + item.fixationError ** 2, 0) / trials.length) : 0.08,
      pursuit_gain: gains.length ? Math.max(0, Math.min(2, median(gains))) : null,
    })
  }

  function startTrial(index) {
    trialRef.current = index
    setTrial(index)
    const side = Math.random() > 0.5 ? 'left' : 'right'
    sideRef.current = side
    setStimulusSide(side)
    responseRef.current = null
    stimulusSamplesRef.current = []
    fixationSamplesRef.current = []
    holdStartedRef.current = null
    changePhase('headlock')
  }

  function beginTest() {
    trialResultsRef.current = []
    calibrationRef.current = { x: [], y: [], headX: [], headY: [] }
    pursuitRef.current = []
    pursuitPreviousRef.current = null
    setCountdown(5)
    changePhase('calibration')
    deadlineRef.current = performance.now() + CALIBRATION_MS
  }

  function retryCamera() {
    setError(null)
    changePhase('requesting')
    window.location.reload()
  }

  useEffect(() => {
    let cancelled = false
    async function initialise() {
      if (!navigator.mediaDevices?.getUserMedia) {
        setError('This browser does not support webcam access.')
        changePhase('error')
        return
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' },
          audio: false,
        })
        if (cancelled) return stream.getTracks().forEach((track) => track.stop())
        streamRef.current = stream
        if (videoRef.current) {
          videoRef.current.srcObject = stream
          await videoRef.current.play()
        }

        const mesh = new FaceMesh({
          locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`,
        })
        mesh.setOptions({
          maxNumFaces: 1,
          refineLandmarks: true,
          minDetectionConfidence: 0.6,
          minTrackingConfidence: 0.6,
        })
        mesh.onResults((results) => {
          const landmarks = results.multiFaceLandmarks?.[0]
          const activePhase = phaseRef.current
          if (!landmarks) {
            faceDetectedRef.current = false
            headInsideRef.current = false
            setFaceDetected(false)
            setHeadInside(false)
            setFaceBox(null)
            return
          }
          faceDetectedRef.current = true
          setFaceDetected(true)
          const facePoints = [10, 152, 234, 454, LANDMARKS.nose]
          const minX = Math.max(0, Math.min(...facePoints.map((index) => landmarks[index].x)) - 0.08)
          const maxX = Math.min(1, Math.max(...facePoints.map((index) => landmarks[index].x)) + 0.08)
          const minY = Math.max(0, Math.min(...facePoints.map((index) => landmarks[index].y)) - 0.1)
          const maxY = Math.min(1, Math.max(...facePoints.map((index) => landmarks[index].y)) + 0.1)
          setFaceBox({
            left: `${(1 - maxX) * 100}%`,
            top: `${minY * 100}%`,
            width: `${(maxX - minX) * 100}%`,
            height: `${(maxY - minY) * 100}%`,
          })
          const headX = (landmarks[LANDMARKS.leftOuter].x + landmarks[LANDMARKS.rightOuter].x + landmarks[LANDMARKS.nose].x) / 3
          const headY = (landmarks[LANDMARKS.leftOuter].y + landmarks[LANDMARKS.rightOuter].y + landmarks[LANDMARKS.nose].y) / 3
          const inside = headX >= 0.5 - 0.16 - HEAD_BOX_TOLERANCE
            && headX <= 0.5 + 0.16 + HEAD_BOX_TOLERANCE
            && headY >= 0.5 - 0.21 - HEAD_BOX_TOLERANCE
            && headY <= 0.5 + 0.21 + HEAD_BOX_TOLERANCE
          setHeadInside(inside)
          headInsideRef.current = inside
          const gaze = gazeFromLandmarks(landmarks)
          if (!gaze) return
          currentGazeRef.current = gaze
          if (activePhase === 'calibration') {
            calibrationRef.current.x.push(gaze.x)
            calibrationRef.current.y.push(gaze.y)
            calibrationRef.current.headX.push(headX)
            calibrationRef.current.headY.push(headY)
          }
          if (activePhase === 'antisaccade') {
            stimulusSamplesRef.current.push({
              time: performance.now(),
              x: gaze.x - baselineRef.current.x,
            })
          }
          if (activePhase === 'fixation') {
            fixationSamplesRef.current.push({
              time: performance.now(),
              x: gaze.x - baselineRef.current.x,
              y: gaze.y - baselineRef.current.y,
            })
          }
          if (activePhase === 'pursuit') {
            const previous = previousGazeRef.current
            const now = performance.now()
            const elapsed = PURSUIT_MS - Math.max(0, deadlineRef.current - now)
            const target = Math.sin((elapsed / PURSUIT_MS) * Math.PI * 10) * 0.76
            const pursuitPrevious = pursuitPreviousRef.current
            if (previous && pursuitPrevious) {
              const dt = Math.max(0.001, (now - pursuitPrevious.time) / 1000)
              const gazeVelocity = Math.abs(gaze.x - previous.x) / dt
              const targetVelocity = Math.abs(target - pursuitPrevious.target) / dt
              if (targetVelocity > 0.01) {
                pursuitRef.current.push({ gazeVelocity, targetVelocity })
              }
            }
            pursuitPreviousRef.current = { target, time: now }
          }
          previousGazeRef.current = gaze
        })
        meshRef.current = mesh
        changePhase('ready')
      } catch (cameraError) {
        setError(cameraError.name === 'NotAllowedError'
          ? 'Camera permission was denied. Allow camera access and try again.'
          : `Unable to access the camera: ${cameraError.message}`)
        changePhase('error')
      }
    }
    initialise()
    return () => {
      cancelled = true
      cancelAnimationFrame(rafRef.current)
      meshRef.current?.close()
      streamRef.current?.getTracks().forEach((track) => track.stop())
    }
  }, [])

  useEffect(() => {
    const tick = async () => {
      if (meshRef.current && videoRef.current?.readyState >= 2 && !trackingBusyRef.current) {
        trackingBusyRef.current = true
        meshRef.current.send({ image: videoRef.current })
          .catch((trackingError) => {
            setError(`Face tracking stopped: ${trackingError.message}`)
            changePhase('error')
          })
          .finally(() => {
            trackingBusyRef.current = false
          })
      }
      const now = performance.now()
      const activePhase = phaseRef.current
      if (activePhase === 'calibration') {
        setCountdown(Math.ceil(Math.max(0, deadlineRef.current - now) / 1000))
        if (now >= deadlineRef.current) {
          baselineRef.current = {
            x: median(calibrationRef.current.x),
            y: median(calibrationRef.current.y),
          }
        changePhase('instructions')
        }
      } else if (activePhase === 'headlock') {
        if (faceDetectedRef.current && headInsideRef.current) {
          if (!holdStartedRef.current) holdStartedRef.current = now
          if (now - holdStartedRef.current >= HEAD_HOLD_MS) {
            changePhase('fixation')
            deadlineRef.current = now + FIXATION_MS
          }
        } else {
          holdStartedRef.current = null
        }
      } else if (activePhase === 'fixation' && now >= deadlineRef.current) {
        changePhase('antisaccade')
        deadlineRef.current = now + RESPONSE_MS
      } else if (activePhase === 'antisaccade' && now >= deadlineRef.current) {
        const stimSamples = stimulusSamplesRef.current
        const result = stimSamples.length
          ? classifySaccade(stimSamples, sideRef.current)
          : { error: true, latency: RESPONSE_MS }
        const fixation = fixationSamplesRef.current
        const meanX = fixation.length ? fixation.reduce((sum, sample) => sum + sample.x, 0) / fixation.length : 0
        const meanY = fixation.length ? fixation.reduce((sum, sample) => sum + sample.y, 0) / fixation.length : 0
        const fixationError = fixation.length
          ? Math.sqrt(fixation.reduce((sum, sample) => sum + (sample.x - meanX) ** 2 + (sample.y - meanY) ** 2, 0) / fixation.length)
          : 0.1
        trialResultsRef.current.push({
          ...result,
          sampleCount: stimulusSamplesRef.current.length,
          fixationError,
        })
        responseRef.current = { ...result, firstSide: result.direction || 'none' }
        changePhase('feedback')
        deadlineRef.current = now + FEEDBACK_MS
      } else if (activePhase === 'feedback' && now >= deadlineRef.current) {
        if (trialRef.current + 1 >= TRIAL_COUNT) {
          pursuitPreviousRef.current = null
          setDotX(50)
          changePhase('pursuit')
          deadlineRef.current = now + PURSUIT_MS
        } else startTrial(trialRef.current + 1)
      } else if (activePhase === 'pursuit') {
        const elapsed = PURSUIT_MS - Math.max(0, deadlineRef.current - now)
        setDotX(50 + Math.sin((elapsed / PURSUIT_MS) * Math.PI * 10) * 38)
        if (now >= deadlineRef.current) {
          changePhase('complete')
          finishTest()
        }
      }
      if (phaseRef.current !== 'error' && phaseRef.current !== 'quality-error') {
        rafRef.current = requestAnimationFrame(tick)
      }
    }
    rafRef.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(rafRef.current)
  }, [])

  const cancelTest = () => {
    streamRef.current?.getTracks().forEach((track) => track.stop())
    onCancel()
  }
  const targetStyle = { position: 'absolute', top: '50%', transform: 'translate(-50%, -50%)', width: 28, height: 28, borderRadius: '50%' }
  const stageMessage = phase === 'calibration' ? 'CALIBRATION · Look at the white dot'
    : phase === 'instructions' ? 'ANTISACCADE TASK · Read the instructions'
      : phase === 'headlock' ? `Trial ${trial + 1}/${TRIAL_COUNT} · Hold position`
        : phase === 'fixation' ? `Trial ${trial + 1}/${TRIAL_COUNT} · Look at the cross`
      : phase === 'antisaccade' ? 'ANTISACCADE · Look opposite to the red stimulus'
        : phase === 'pursuit' ? 'SMOOTH PURSUIT · Follow the green dot with your eyes' : ''
  const stageTarget = phase === 'antisaccade' ? (stimulusSide === 'left' ? 20 : 80) : dotX
  const progress = phase === 'antisaccade' ? ((trial + 1) / TRIAL_COUNT) * 100 : 0

  return (
    <div className="fixed inset-0 z-50" style={{ background: '#121220' }}>
      <div className="relative h-full w-full overflow-hidden" style={{ boxShadow: 'var(--shadow-dark)' }}>
        <div className="absolute left-0 right-0 top-0 z-10 flex items-center justify-between px-6 py-5">
          <div><p className="text-xs font-semibold tracking-widest text-white/90">COGNISENSE · OCULOMOTOR ASSESSMENT</p></div>
          <button type="button" onClick={cancelTest} aria-label="Close oculomotor test" className="rounded-full p-2 text-white hover:bg-white/10"><X size={18} /></button>
        </div>
        <div className="h-full w-full">
          <div className="relative h-full w-full overflow-hidden" style={{ background: '#121220' }}>
            <video ref={videoRef} autoPlay muted playsInline className="absolute inset-0 h-full w-full object-contain -scale-x-100" />
            <div className="absolute inset-0 bg-[#121220]/55" />
            <div className="absolute inset-0 flex items-center justify-center">
              {phase === 'calibration' && <div className="h-12 w-12 rounded-full bg-white" />}
              {phase === 'fixation' && <div className="relative h-16 w-16"><div className="absolute left-1/2 top-0 h-full w-1 -translate-x-1/2 bg-white" /><div className="absolute left-0 top-1/2 h-1 w-full -translate-y-1/2 bg-white" /></div>}
              {phase === 'headlock' && <div className="text-center text-white"><p className="text-lg">Keep your head inside the green box</p><p className="mt-2 text-sm opacity-80">Hold still for 0.6 seconds</p></div>}
              {phase === 'antisaccade' && <div style={{ ...targetStyle, left: `${stageTarget}%`, background: '#3c3ce6', boxShadow: '0 0 0 8px rgba(230,60,60,0.18)' }} />}
              {phase === 'pursuit' && <div style={{ ...targetStyle, left: `${stageTarget}%`, width: 42, height: 42, background: '#50e650', boxShadow: '0 0 0 18px rgba(80,230,80,0.24), 0 0 35px rgba(80,230,80,0.9)' }} />}
            </div>
            {stageMessage && <p className="absolute left-5 top-20 z-10 max-w-[45%] text-xs font-semibold tracking-widest text-white/90">{stageMessage}</p>}
            {phase === 'calibration' && <p className="absolute bottom-20 left-0 right-0 text-center text-sm text-white/80">{countdown}s remaining</p>}
            {phase === 'instructions' && <div className="absolute inset-0 flex items-center justify-center bg-[#121220]/95 px-8 text-center text-white"><div><p className="text-xl font-semibold text-[#ffc832]">ANTISACCADE TASK</p><p className="mt-5">A red dot will appear on the LEFT or RIGHT.</p><p className="mt-2">Look HARD to the OPPOSITE side.</p><p className="mt-2 text-sm text-white/70">Do not move your head. Keep it inside the preview box.</p><Button className="mt-6" onClick={() => startTrial(0)}>Press to begin</Button></div></div>}
            {phase === 'antisaccade' && <p className="absolute bottom-20 left-0 right-0 text-center text-lg text-white">Look to the opposite side</p>}
            {phase === 'feedback' && <div className="absolute inset-0 flex items-center justify-center bg-[#121220]/90"><div className="rounded-lg px-8 py-4 text-center text-white" style={{ background: responseRef.current?.error ? '#3c3ce6' : '#50c850' }}><p className="text-2xl font-bold">{responseRef.current?.error ? 'WRONG SIDE ✗' : 'CORRECT ✓'}</p><p className="mt-2 text-sm">Trial {trial + 1} · latency {Math.round(responseRef.current?.latency || 0)} ms</p></div></div>}
            {phase === 'pursuit' && <div className="absolute bottom-20 left-0 right-0 text-center text-white"><p className="text-xl font-semibold">SMOOTH PURSUIT</p><p className="mt-1 text-sm">Follow the green dot with your eyes</p></div>}
            <div className="absolute bottom-5 left-[15%] right-[15%] h-2 rounded bg-white/15"><div className="h-full rounded bg-[#50c850]" style={{ width: `${progress}%` }} /></div>
            <div
              className="pointer-events-none absolute left-1/2 top-1/2 h-[42%] w-[32%] -translate-x-1/2 -translate-y-1/2 border-2 border-dashed"
              style={{ borderColor: headInside ? 'rgba(80,220,80,0.6)' : 'rgba(230,60,60,0.8)' }}
            />
            {faceBox && <div className="pointer-events-none absolute border-4" style={{ ...faceBox, borderColor: headInside ? '#50dc50' : '#e63c3c', boxShadow: headInside ? '0 0 24px rgba(80,220,80,0.45)' : '0 0 24px rgba(230,60,60,0.45)' }} />}
            <div className="absolute right-6 top-20 rounded-lg px-4 py-3 text-right text-xs font-semibold" style={{ color: headInside ? '#50dc50' : '#e63c3c', background: 'rgba(0,0,0,0.45)' }}>{faceDetected ? (headInside ? 'Head: INSIDE box ✓' : 'Head: MOVE INSIDE box') : 'Face: NOT detected'}</div>
            {phase === 'requesting' && <div className="absolute inset-0 flex items-center justify-center text-white"><Camera className="mr-2" size={18} /> Loading full-screen camera and face tracker…</div>}
            {phase === 'error' && <div className="absolute inset-0 flex flex-col items-center justify-center px-6 text-center text-white"><AlertCircle size={28} className="mb-3" /><p>{error}</p><Button className="mt-6" onClick={retryCamera}>Retry camera</Button></div>}
            {phase === 'quality-error' && <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#121220]/95 px-8 text-center text-white"><AlertCircle size={34} className="mb-3 text-[#ffc832]" /><p className="text-xl font-semibold">Result not reliable</p><p className="mt-3 max-w-lg text-sm text-white/75">{error}</p><Button className="mt-6" onClick={cancelTest}>Close and retry</Button></div>}
            {phase === 'ready' && <div className="absolute inset-0 flex items-center justify-center"><div className="text-center text-white"><CheckCircle2 size={34} className="mx-auto mb-3" /><p className="text-lg">{headInside ? 'Camera and face tracker ready' : 'Centre your head inside the green box'}</p><Button className="mt-4" onClick={beginTest} disabled={!headInside}>Start test</Button></div></div>}
          </div>
        </div>
      </div>
    </div>
  )
}
