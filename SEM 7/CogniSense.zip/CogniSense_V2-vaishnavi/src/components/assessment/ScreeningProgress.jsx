const STEPS = ['Speech', 'Clock Drawing', 'Oculomotor', 'Final Results']

export default function ScreeningProgress({ activeStep }) {
  return (
    <div
      className="rounded-xl px-4 py-3 mb-6"
      style={{ background: 'var(--bg-surface)', border: '1px solid var(--border-light)' }}
      aria-label={`Full screening progress: step ${activeStep} of 4`}
    >
      <div className="flex items-center justify-between gap-2 overflow-x-auto">
        {STEPS.map((step, index) => {
          const number = index + 1
          const complete = number < activeStep
          const active = number === activeStep
          return (
            <div key={step} className="flex items-center gap-2 shrink-0">
              <span
                className="flex items-center justify-center rounded-full"
                style={{
                  width: 24,
                  height: 24,
                  fontSize: '0.7rem',
                  background: complete || active ? 'var(--accent-primary)' : 'var(--divider)',
                  color: complete || active ? '#fff' : 'var(--text-muted)',
                }}
              >
                {number}
              </span>
              <span
                style={{
                  fontSize: '0.75rem',
                  fontWeight: active ? 600 : 400,
                  color: active ? 'var(--text-primary)' : 'var(--text-muted)',
                }}
              >
                {step}
              </span>
              {index < STEPS.length - 1 && (
                <span className="mx-1" style={{ color: 'var(--divider)' }}>—</span>
              )}
            </div>
          )
        })}
      </div>
      <p className="label-mono mt-2">Guided screening session · results save automatically after each module</p>
    </div>
  )
}
